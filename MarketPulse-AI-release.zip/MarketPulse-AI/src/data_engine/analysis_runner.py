"""Orchestrates the full dataset-first pipeline for one dataset_id:

  load raw -> profile+map -> standardize -> detect capabilities
  -> persist standardized data + capabilities.json + generic_kpis.json
     + universal_kpis.json to data/uploads/<dataset_id>/{processed,models}/
  -> conditionally run a lightweight generic MMM stage (if capability available)
  -> conditionally run a lightweight generic forecast stage (if capability available)
  -> conditionally run ROI stage (if capability available)

Every skipped stage is recorded with an explicit reason — never silently
skipped, never fabricated.
"""

import json
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from config.settings import ensure_dataset_dirs, dataset_processed_dir, dataset_models_dir, dataset_raw_path
from src.data_engine.pipeline import profile_and_map, confirm_and_standardize
from src.data_engine.capability_engine import detect_capabilities
from src.data_engine.canonical import CanonicalDataset, AnalysisContext, UserOverrides
from src.kpi.generic_kpis import compute_generic_kpis

DATASET_ID_PATTERN = re.compile(r"^[a-zA-Z0-9_-]{1,64}$")


def normalize_duplicate_columns(df: pd.DataFrame) -> tuple:
    """Detect and rename duplicate column names deterministically.

    Returns (df_with_unique_columns, rename_map_or_None).
    - If no duplicates, returns (df, None).
    - If duplicates exist, renames them as ``Name``, ``Name_1``, ``Name_2``, …,
      avoiding collisions with existing column names.
    - Column order and all data values are preserved.
    """
    cols = list(df.columns)
    if len(cols) == len(set(cols)):
        return df, None

    existing_names = set(cols)
    seen: dict[str, int] = {}
    new_cols = []
    rename_map = {}

    for col in cols:
        if col not in seen:
            seen[col] = 0
            new_cols.append(col)
        else:
            seen[col] += 1
            candidate = f"{col}_{seen[col]}"
            # Avoid collisions with any existing or already-assigned name
            while candidate in existing_names or candidate in set(new_cols):
                seen[col] += 1
                candidate = f"{col}_{seen[col]}"
            new_cols.append(candidate)
            existing_names.add(candidate)
            rename_map[candidate] = col  # new_name -> original_name

    df = df.copy()
    df.columns = new_cols
    return df, rename_map


def validate_dataset_id(dataset_id: str) -> str:
    if not dataset_id or not DATASET_ID_PATTERN.match(dataset_id):
        raise ValueError(
            f"Invalid dataset_id {dataset_id!r} — must match {DATASET_ID_PATTERN.pattern}."
        )
    return dataset_id


def _run_generic_mmm(dataset, models_dir: Path, processed_dir: Path, report: list) -> None:
    """A lightweight, genuinely-computed (not fabricated) linear
    channel-contribution model: Ridge regression of revenue on channel
    spend + numeric controls. Not the full adstock/saturation legacy MMM —
    it exists so an arbitrary dataset's marketing_mix_modeling capability
    produces real numbers rather than nothing.

    Outputs are written in the SAME schema the dashboard pages expect
    (channel_attribution.csv with Rank, Channel, Spend, Estimated_Contribution,
    Contribution_Pct, Observed_Naive_ROAS, Model_Estimated_Efficiency;
    model_metrics.json with selected_model + model_comparison structure)
    so pages 3, 4, and 9 can consume them without adapters."""
    try:
        from sklearn.linear_model import Ridge
        from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error, mean_absolute_percentage_error

        df = dataset.df
        channel_cols = list(dataset.channels)
        control_cols = [c for c in dataset.control_cols if c in df.columns]
        X_cols = channel_cols + control_cols
        X = df[X_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)
        y = pd.to_numeric(df[dataset.revenue_col], errors="coerce").fillna(0.0)

        model = Ridge(alpha=1.0)
        model.fit(X, y)
        preds = model.predict(X)

        r2 = float(r2_score(y, preds)) if len(y) > 1 else 0.0
        rmse = float(np.sqrt(mean_squared_error(y, preds))) if len(y) > 1 else 0.0
        mae = float(mean_absolute_error(y, preds)) if len(y) > 1 else 0.0
        try:
            y_nonzero = y.replace(0, np.nan).dropna()
            mape = float(mean_absolute_percentage_error(
                y_nonzero, pd.Series(preds, index=y.index).loc[y_nonzero.index]
            )) * 100  # as percentage
        except Exception:
            mape = None

        # --- Build channel_attribution.csv in the dashboard-expected schema ---
        coefs = {col: float(coef) for col, coef in zip(X_cols, model.coef_)}
        total_revenue = float(y.sum()) or 1.0

        attribution_rows = []
        for rank, ch in enumerate(channel_cols, 1):
            spend_total = float(df[ch].apply(pd.to_numeric, errors="coerce").fillna(0.0).sum())
            coef = coefs[ch]
            # Estimated contribution: coefficient * total spend for that channel
            estimated_contribution = abs(coef) * spend_total
            # Naive ROAS: total revenue / total spend
            naive_roas = (total_revenue / spend_total) if spend_total > 0 else 0.0
            # Model efficiency: estimated contribution / spend
            efficiency = (estimated_contribution / spend_total) if spend_total > 0 else 0.0

            attribution_rows.append({
                "Rank": rank,
                "Channel": ch,
                "Spend": round(spend_total, 2),
                "Estimated_Contribution": round(estimated_contribution, 2),
                "Observed_Naive_ROAS": round(naive_roas, 2),
                "Model_Estimated_Efficiency": round(efficiency, 4),
            })

        # Compute Contribution_Pct from estimated contributions
        total_contribution = sum(r["Estimated_Contribution"] for r in attribution_rows) or 1.0
        for row in attribution_rows:
            row["Contribution_Pct"] = round(row["Estimated_Contribution"] / total_contribution * 100, 2)

        # Sort by efficiency descending and re-rank
        attribution_rows.sort(key=lambda r: r["Model_Estimated_Efficiency"], reverse=True)
        for i, row in enumerate(attribution_rows, 1):
            row["Rank"] = i

        attr_df = pd.DataFrame(attribution_rows)
        # Write to BOTH models/ and processed/ so loaders find it
        attr_df.to_csv(models_dir / "channel_attribution.csv", index=False)
        attr_df.to_csv(processed_dir / "channel_attribution.csv", index=False)

        # --- Build model_metrics.json in the dashboard-expected schema ---
        model_name = "generic_ridge_linear"
        metrics_dict = {
            "selected_model": model_name,
            "model_comparison": {
                model_name: {
                    "test": {
                        "r2": round(r2, 4),
                        "rmse": round(rmse, 2),
                        "mae": round(mae, 2),
                        "mape": round(mape, 2) if mape is not None else 0.0,
                    }
                }
            },
            # Extra metadata for transparency
            "n_observations": int(len(y)),
            "features": X_cols,
            "model_type": model_name,
        }
        with open(models_dir / "model_metrics.json", "w") as f:
            json.dump(metrics_dict, f, indent=2)

        report.append(f"Generic MMM (Ridge regression) trained: R2={r2:.3f} on {len(y)} rows, {len(X_cols)} feature(s).")
    except Exception as e:
        report.append(f"Marketing mix modeling was available but failed to train: {e}")


def _run_generic_forecast(dataset, models_dir: Path, processed_dir: Path, report: list) -> None:
    """Lightweight linear-trend forecast. Outputs revenue_forecast.csv with
    the SAME column names the dashboard page 7 expects: Date, Forecast_Revenue,
    Lower_90, Upper_90. Dates are projected forward from the dataset's last date."""
    try:
        from sklearn.linear_model import Ridge

        target_col = dataset.revenue_col or (dataset.control_cols[0] if dataset.control_cols else None)
        if not target_col:
            report.append("Forecasting skipped: no numeric target column available.")
            return

        df = dataset.df.copy()
        df = df.sort_values(dataset.date_col)
        y = pd.to_numeric(df[target_col], errors="coerce").ffill().fillna(0.0).values
        n = len(y)
        idx = np.arange(n).reshape(-1, 1)
        model = Ridge(alpha=1.0)
        model.fit(idx, y)

        horizon = min(12, max(1, n // 4))
        future_idx = np.arange(n, n + horizon).reshape(-1, 1)
        forecast_vals = model.predict(future_idx)
        resid_std = float(np.std(y - model.predict(idx))) if n > 1 else 0.0

        # Project dates forward from the dataset's last date
        dates_series = pd.to_datetime(df[dataset.date_col], errors="coerce").dropna()
        if len(dates_series) >= 2:
            # Infer frequency from the median gap between consecutive dates
            gaps = dates_series.diff().dropna()
            median_gap = gaps.median()
            last_date = dates_series.max()
            future_dates = [last_date + median_gap * (i + 1) for i in range(horizon)]
        elif len(dates_series) == 1:
            last_date = dates_series.iloc[0]
            future_dates = [last_date + pd.Timedelta(weeks=i + 1) for i in range(horizon)]
        else:
            # No valid dates — use step numbers as fallback
            future_dates = list(range(1, horizon + 1))

        out = pd.DataFrame({
            "Date": future_dates,
            "Forecast_Revenue": forecast_vals,
            "Lower_90": forecast_vals - 1.645 * resid_std,
            "Upper_90": forecast_vals + 1.645 * resid_std,
        })
        out.to_csv(processed_dir / "revenue_forecast.csv", index=False)
        report.append(f"Generic forecast (linear trend) produced for '{target_col}': {horizon} step(s) ahead.")
    except Exception as e:
        report.append(f"Forecasting was available but failed to run: {e}")


def run_full_analysis(dataset_id: str, df: pd.DataFrame = None, mapping=None, confirmed_roles=None, overrides=None):
    """Runs the entire dataset-first pipeline for `dataset_id`. If `df` is
    not given, reads the previously-saved raw file for this dataset_id.
    Returns a dict with dataset, capabilities, generic_kpis, report."""
    validate_dataset_id(dataset_id)
    ensure_dataset_dirs(dataset_id)
    processed_dir = dataset_processed_dir(dataset_id)
    models_dir = dataset_models_dir(dataset_id)

    if df is None:
        raw_dir = dataset_raw_path(dataset_id, "").parent
        candidates = list(raw_dir.glob("*.csv")) + list(raw_dir.glob("*.xlsx"))
        if not candidates:
            raise FileNotFoundError(f"No raw upload found for dataset_id={dataset_id!r}.")
        path = candidates[0]
        df = pd.read_csv(path) if path.suffix == ".csv" else pd.read_excel(path)

    # --- Duplicate column guard (M-1) ---
    df, dup_rename_map = normalize_duplicate_columns(df)

    if mapping is None:
        _, mapping = profile_and_map(df)

    dataset, map_report = confirm_and_standardize(df, mapping, confirmed_roles=confirmed_roles, overrides=overrides)
    capabilities = detect_capabilities(dataset)

    report = list(map_report)

    if dup_rename_map:
        report.insert(0, f"Duplicate column names detected and normalized: "
                         f"{', '.join(f'{v!r} -> {k!r}' for k, v in dup_rename_map.items())}.")

    # Persist standardized data
    dataset.df.to_csv(processed_dir / "standardized_data.csv", index=False)

    # Generic KPIs (always computed — never fabricated)
    generic_kpis = compute_generic_kpis(dataset)
    with open(processed_dir / "generic_kpis.json", "w") as f:
        json.dump([k.to_dict() for k in generic_kpis], f, indent=2)
    with open(processed_dir / "universal_kpis.json", "w") as f:
        json.dump({
            "has_date": dataset.has_date, "has_revenue": dataset.has_revenue,
            "n_channels": len(dataset.channels), "n_rows": len(dataset.df),
            "n_controls": len(dataset.control_cols), "n_dimensions": len(dataset.dimension_cols),
            "date_column": dataset.date_col, "revenue_column": dataset.revenue_col,
            "channel_columns": dataset.channels, "dimension_columns": dataset.dimension_cols,
            "control_columns": dataset.control_cols, "identifier_columns": dataset.identifier_cols,
        }, f, indent=2)

    with open(processed_dir / "capabilities.json", "w") as f:
        json.dump(capabilities.to_dict(), f, indent=2)

    # Legacy marketing_analytics stage: only meaningful when the dataset has
    # date + revenue (the minimum the legacy KPI shape needs).
    if dataset.has_date and dataset.has_revenue:
        report.append(f"Date+revenue present — generic KPI/trend analytics are computed for '{dataset.revenue_col}'.")
    else:
        report.append("Legacy-style revenue/date analytics skipped: date and/or revenue column not identified.")

    # Marketing Mix Modeling stage
    if capabilities.is_available("marketing_mix_modeling"):
        _run_generic_mmm(dataset, models_dir, processed_dir, report)
    else:
        report.append(f"Marketing mix modeling stage skipped: {capabilities.get('marketing_mix_modeling').reason}")

    # Forecast stage
    if capabilities.is_available("forecasting"):
        _run_generic_forecast(dataset, models_dir, processed_dir, report)
    else:
        report.append(f"Forecasting stage skipped: {capabilities.get('forecasting').reason}")

    # ROI stage
    if capabilities.is_available("roi_roas"):
        try:
            df2 = dataset.df
            rows = []
            for ch in dataset.channels:
                spend = pd.to_numeric(df2[ch], errors="coerce").fillna(0.0).sum()
                revenue_total = pd.to_numeric(df2[dataset.revenue_col], errors="coerce").fillna(0.0).sum()
                roas = (revenue_total / spend) if spend else None
                rows.append({"channel": ch, "total_spend": float(spend), "roas": (float(roas) if roas is not None else None)})
            pd.DataFrame(rows).to_csv(processed_dir / "channel_roi.csv", index=False)
            report.append(f"ROI/ROAS computed for {len(rows)} channel(s).")
        except Exception as e:
            report.append(f"ROI/ROAS stage was available but failed: {e}")
    else:
        report.append(f"ROI/ROAS stage skipped: {capabilities.get('roi_roas').reason}")

    if not capabilities.is_available("budget_optimization"):
        report.append(f"Budget optimization skipped: {capabilities.get('budget_optimization').reason}")
    if not capabilities.is_available("what_if_simulation"):
        report.append(f"What-if simulation skipped: {capabilities.get('what_if_simulation').reason}")

    # Phase 2: Build canonical dataset + analysis context (backward-compatible addition)
    canonical = CanonicalDataset.from_standardized(
        dataset_id=dataset_id,
        std_dataset=dataset,
        filename="",
        capability_report=capabilities,
    )
    context = AnalysisContext.from_canonical(canonical)

    # Persist canonical metadata alongside existing artifacts
    with open(processed_dir / "canonical_metadata.json", "w") as f:
        json.dump(canonical.to_metadata_dict(), f, indent=2, default=str)

    # Phase 3: Run dynamic analytics engines and persist results
    analytics_result_dict = None
    try:
        from src.analytics.contracts import AnalyticsResult
        from src.analytics.kpi_engine import discover_kpis
        from src.analytics.visualization_engine import recommend_charts
        from src.analytics.insight_engine import discover_insights
        from src.analytics.relationship_engine import analyze_relationships

        analytics_result = AnalyticsResult(
            dataset_id=dataset_id,
            kpis=discover_kpis(context),
            charts=recommend_charts(context),
            insights=discover_insights(context),
            relationships=analyze_relationships(context),
        )
        analytics_result_dict = analytics_result.to_dict()
        with open(processed_dir / "dynamic_analytics.json", "w") as f:
            json.dump(analytics_result_dict, f, indent=2, default=str)
        report.append(
            f"Phase 3 dynamic analytics: {len(analytics_result.kpis)} KPI(s), "
            f"{len(analytics_result.charts)} chart(s), "
            f"{len(analytics_result.insights)} insight(s), "
            f"{len(analytics_result.relationships)} relationship(s)."
        )
    except Exception as e:
        report.append(f"Phase 3 dynamic analytics failed (non-fatal): {e}")

    # Phase 4: Run predictive analytics engines and persist results
    prediction_report_dict = None
    try:
        from src.prediction.task_detector import detect_predictive_tasks
        from src.prediction.contracts import PredictionReport
        from src.prediction.forecasting_engine import run_forecast
        from src.prediction.regression_engine import run_regression
        from src.prediction.classification_engine import run_classification
        from src.prediction.segmentation_engine import run_segmentation

        tasks = detect_predictive_tasks(context)
        pred_report = PredictionReport(dataset_id=dataset_id, tasks=tasks)

        for task in tasks:
            if not task.requirements_met:
                continue
            try:
                if task.task_type == "forecasting":
                    pred_report.forecast = run_forecast(context, target_column=task.target_column)
                elif task.task_type == "regression":
                    pred_report.regression = run_regression(context, target_column=task.target_column)
                elif task.task_type == "classification":
                    pred_report.classification = run_classification(context, target_column=task.target_column)
                elif task.task_type == "segmentation":
                    pred_report.segmentation = run_segmentation(context)
            except Exception as task_err:
                report.append(f"Phase 4 {task.task_type} failed (non-fatal): {task_err}")

        prediction_report_dict = pred_report.to_dict()
        with open(processed_dir / "prediction_report.json", "w") as f:
            json.dump(prediction_report_dict, f, indent=2, default=str)

        completed = [t for t in ["forecast", "regression", "classification", "segmentation"]
                     if getattr(pred_report, t) is not None]
        report.append(
            f"Phase 4 prediction: {len(tasks)} task(s) detected, "
            f"{len(completed)} completed ({', '.join(completed) if completed else 'none'})."
        )
    except Exception as e:
        report.append(f"Phase 4 prediction failed (non-fatal): {e}")

    # Phase 5: Run anomaly detection + driver intelligence and persist results
    phase5_result_dict = None
    try:
        from src.anomaly.detector import detect_anomalies
        from src.anomaly.driver_engine import analyze_drivers
        from src.anomaly.contracts import Phase5Result

        anomaly_report = detect_anomalies(context, dataset_id)
        driver_report = analyze_drivers(context, dataset_id)

        phase5_result = Phase5Result(
            dataset_id=dataset_id,
            anomaly_report=anomaly_report,
            driver_report=driver_report,
        )
        phase5_result_dict = phase5_result.to_dict()
        with open(processed_dir / "phase5_analysis.json", "w") as f:
            json.dump(phase5_result_dict, f, indent=2, default=str)

        n_anomalies = len(anomaly_report.anomalies) if anomaly_report else 0
        n_drivers = len(driver_report.drivers) if driver_report else 0
        target_info = f"target='{driver_report.target_column}'" if driver_report and driver_report.target_column else "no target"
        report.append(
            f"Phase 5 anomaly+driver analysis: {n_anomalies} anomaly(ies), "
            f"{n_drivers} driver(s) ({target_info})."
        )
    except Exception as e:
        report.append(f"Phase 5 anomaly+driver analysis failed (non-fatal): {e}")

    # Phase 6: Run marketing intelligence pipeline and persist results
    phase6_result_dict = None
    try:
        from src.marketing.orchestrator import run_marketing_analysis

        phase6_result = run_marketing_analysis(
            canonical=canonical,
            context=context,
            dataset_id=dataset_id,
        )
        phase6_result_dict = phase6_result.to_dict()
        with open(processed_dir / "phase6_marketing.json", "w") as f:
            json.dump(phase6_result_dict, f, indent=2, default=str)

        readiness = "NOT_READY"
        n_channels = 0
        if phase6_result.marketing_report:
            readiness = phase6_result.marketing_report.readiness.value
            n_channels = len(phase6_result.marketing_report.channel_fields)
        has_mmm = phase6_result.mmm_result is not None and phase6_result.mmm_result._model is not None
        report.append(
            f"Phase 6 marketing intelligence: readiness={readiness}, "
            f"{n_channels} channel(s), MMM={'fitted' if has_mmm else 'not fitted'}."
        )
    except Exception as e:
        report.append(f"Phase 6 marketing intelligence failed (non-fatal): {e}")

    # Phase 7: Run Decision Intelligence orchestrator and persist results
    decision_report_dict = None
    phase7_path = processed_dir / "phase7_decisions.json"
    # Stale-result protection: remove any previous report before running
    # so a failure cannot leave an old report masquerading as current.
    if phase7_path.exists():
        phase7_path.unlink()
    try:
        from src.decision.orchestrator import DecisionOrchestrator, OrchestrationRequest

        request = OrchestrationRequest(
            dataset_id=dataset_id,
            analytics_result=analytics_result_dict,
            prediction_report=prediction_report_dict,
            phase5_result=phase5_result_dict,
            marketing_result=phase6_result_dict,
        )
        orchestrator = DecisionOrchestrator()
        orch_report = orchestrator.run(request)
        decision_report_dict = orch_report.to_dict()
        with open(phase7_path, "w") as f:
            json.dump(decision_report_dict, f, indent=2, default=str)

        n_decisions = len(orch_report.decisions())
        report.append(
            f"Phase 7 decision intelligence: status={orch_report.status}, "
            f"{n_decisions} decision(s) generated."
        )
    except Exception as e:
        report.append(f"Phase 7 decision intelligence failed (non-fatal): {e}")
        # Persist a failure marker so consumers can distinguish
        # "failed" from "never run".
        try:
            with open(phase7_path, "w") as f:
                json.dump({
                    "dataset_id": dataset_id,
                    "status": "failed",
                    "error": str(e),
                }, f, indent=2)
        except Exception:
            pass  # Best-effort — filesystem errors don't crash the pipeline

    return {
        "dataset": dataset,
        "capabilities": capabilities,
        "generic_kpis": generic_kpis,
        "report": report,
        # Phase 2 additions (backward-compatible — new keys only)
        "canonical": canonical,
        "context": context,
        # Phase 4 addition
        "prediction_report": prediction_report_dict,
        # Phase 5 addition
        "phase5_result": phase5_result_dict,
        # Phase 6 addition
        "phase6_result": phase6_result_dict,
        # Phase 7 addition
        "decision_report": decision_report_dict,
    }
