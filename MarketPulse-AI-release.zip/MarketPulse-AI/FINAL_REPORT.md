# MarketPulse AI — Final Engineering Report

## 1. What the platform does

MarketPulse AI is a Marketing Mix Modeling (MMM) and budget-optimization
platform delivered as a Streamlit dashboard (`app.py`) and a FastAPI
backend (`api/main.py`). It was originally built around one fixed
synthetic dataset ("NovaMart") with a hardcoded weekly marketing-spend
schema. This release upgrades the platform to be **dataset-first /
schema-agnostic**: a person can upload any reasonably-structured CSV or
Excel file, and the platform profiles it, semantically classifies its
columns, and dynamically determines which analyses (KPIs, trend
analysis, forecasting, MMM, ROI, budget optimization, AI analyst, etc.)
are actually valid for that data — never assuming a fixed schema, never
fabricating results for analyses a dataset can't support.

The built-in NovaMart demo dataset remains fully supported end to end
(the original adstock/saturation MMM, forecasting, and budget-optimizer
pipeline is untouched) and now sits alongside the general upload path as
one of several supported datasets rather than the only one.

## 2. Dataset-first architecture, in one flow

Upload → **profile** (`src/data_engine/profiler.py` infers each column's
type — numeric/categorical/datetime/text/identifier — plus missing-data
rate and cardinality, with no hardcoded column names) → **semantic
classification** (`src/data_engine/column_classifier.py` matches
normalized column names against generic alias vocabularies in
`config/column_aliases.py` for roles like date, revenue, sales, cost,
impressions, clicks, conversions, orders, profit, margin, and
per-channel/generic marketing spend, producing a confidence score per
guess: alias-exact ≈0.95, alias-fuzzy ≈0.70–0.80, statistical fallback
≈0.40–0.55) → **confidence-based mapping** (HIGH-confidence guesses,
≥0.80, are auto-selected; MEDIUM/LOW guesses are surfaced to the user
with their confidence and require explicit confirmation or an override
before use — enforced in `ColumnMapping.clear_unconfirmed_low_confidence`
in `src/data_engine/schemas.py`, never silently applied) →
**standardize** (`src/data_engine/data_standardizer.py` builds a
`StandardizedDataset` with first-class date/revenue/channel slots plus
generic numeric "control" columns, categorical "dimension" columns, and
near-unique "identifier" columns for everything left over — nothing is
dropped) → **capability detection** (`src/data_engine/capability_engine.py`
inspects the standardized dataset and returns, per possible analysis, a
boolean `available` plus a specific, honest, plain-English `reason` —
e.g. "fewer than 2 marketing spend/channel columns identified (found 0)")
→ **conditional analytics stages** (`src/data_engine/analysis_runner.py`
orchestrates generic-KPI computation, a lightweight generic MMM, a
lightweight generic forecast, and ROI/ROAS — each stage runs only if its
capability is available, and every skip is recorded in a human-readable
report rather than silently omitted) → **dynamic dashboard/API**: the
Streamlit "Upload Data" page (`dashboard/pages/0_upload_data.py`) shows
the profile, confidence-badged column guesses, and lets the user
confirm/override before running the pipeline; `api/main.py` exposes the
same flow as `POST /upload` and `POST /datasets/{dataset_id}/confirm`,
and every existing analytics endpoint accepts an optional `dataset_id`
query parameter so the same API surface serves both the demo dataset and
any number of uploaded datasets.

Each uploaded dataset gets an isolated directory tree —
`data/uploads/<dataset_id>/{raw,processed,models}/` — completely separate
from the demo dataset's `data/processed/`/`models/` and from every other
uploaded dataset. `dataset_id`s are validated against a strict allowlist
pattern (`^[a-zA-Z0-9_-]{1,64}$`) before ever touching the filesystem, so
path-traversal input is rejected outright.

## 3. Test results

**69/69 tests passing** — the pre-existing legacy MMM/forecasting/
optimization test suite plus the new dataset-first suite
(`tests/test_dataset_first_platform.py`), which covers:

- All 5 fixture schemas (marketing, interaction-only, sales-only,
  arbitrary/ambiguous naming, no-marketing-signal) profile, classify, and
  standardize without raising, and complete the full analysis pipeline
  end to end.
- Capability detection returns correct, non-empty, honest reasons for
  every capability on every fixture — including confirming that datasets
  without marketing signal correctly report MMM/ROI/budget-optimization/
  what-if as unavailable, while profiling/generic-KPIs/AI-analyst/
  business-report remain available.
- Low/medium-confidence guesses are provably never auto-applied (e.g. a
  weak statistical guess for "revenue" is not used unless the role is in
  `confirmed_roles`), and explicit confirmation correctly promotes a
  medium/low-confidence guess into the standardized dataset.
- Dataset isolation: running the pipeline for one dataset never mutates
  or leaks into another dataset's directory or capability results; the
  demo dataset's directory is structurally separate from any upload.
- `dataset_id` validation rejects path traversal and malformed IDs.
- Generic KPIs are non-empty, genuinely computed from the actual data
  (not fabricated), and differ across structurally different datasets;
  an empty dataset yields an empty KPI list rather than an error.
- XLSX and CSV uploads of the same data profile and standardize
  identically (openpyxl-backed round trip).
- A short-token fuzzy-matching guard prevents false positives (e.g.
  `digital_score` is not misclassified as an Instagram spend column via
  a naive substring match on "ig").
- FastAPI round trips: `POST /upload` → `POST /datasets/{id}/confirm` →
  `GET /kpis?dataset_id=...` for both a no-revenue dataset (marketing
  KPIs correctly unavailable) and an ambiguous-field dataset (behavior
  differs correctly between default confirmation and explicit
  `accept_suggested`).

Per the task instructions, the test suite was not re-run as part of this
documentation pass — the above reflects the ground truth captured in the
test file itself and the 69/69 passing state stated as the starting
condition for this work.

## 4. What's NOT implemented / known limitations

- **The generic MMM/forecast path is intentionally simplified.** For an
  arbitrary uploaded dataset, `analysis_runner._run_generic_mmm` fits a
  plain Ridge regression of revenue on channel spend + numeric controls
  (no adstock/carryover, no saturation/diminishing-returns curve), and
  `_run_generic_forecast` fits a Ridge regression on a simple linear time
  index (no seasonality/Fourier terms). This is explicitly **not** the
  full adstock + Hill-saturation MMM and Fourier-seasonal forecast that
  the legacy NovaMart pipeline (`src/models/`, `src/forecasting/`) uses.
  The generic path exists so an arbitrary dataset's `marketing_mix_modeling`
  / `forecasting` capabilities produce real, honestly-labeled numbers
  (`model_type: "generic_ridge_linear"` in `model_metrics.json`) rather
  than nothing — but it should not be read as equivalent in
  sophistication to the legacy demo-dataset model.
- **Channel attribution for the generic path** is derived from raw Ridge
  coefficients (relative absolute-coefficient share), not the
  leave-one-channel-out ablation method the legacy model uses.
- **Budget optimization and what-if simulation** are gated on
  `mmm_readiness` (date + revenue + ≥2 channels) but there is no generic
  budget-optimizer or simulator implementation for arbitrary datasets in
  this release — those capabilities report available/unavailable based
  on MMM readiness, but the actual optimize/simulate logic in
  `src/optimization/` still targets the legacy 8-channel NovaMart schema
  (`CHANNELS` constant) and is not yet dataset-agnostic.
- **Row limits**: uploads are capped at `MAX_ROWS` (default 100,000,
  truncated silently to the head) and `MAX_UPLOAD_MB` (default 50MB,
  rejected with `413` if exceeded) — configurable via environment
  variables, not dynamically negotiated.
- **No persistent dataset registry across API process restarts**: an
  uploaded-but-unconfirmed dataset lives in an in-memory dict
  (`_UPLOAD_REGISTRY` in `api/main.py`); if the API process restarts
  before `/confirm` is called, that in-flight upload is lost (though the
  raw file itself is already persisted to disk). Confirmed/analyzed
  datasets are fully persisted and survive restarts.
- **Statistical fallback classification is heuristic**, not learned —
  date/revenue guesses below alias-match confidence use simple parse-rate
  and coefficient-of-variation heuristics, which is why they're capped at
  LOW/MEDIUM confidence and require explicit user confirmation.

## 5. Production-oriented, not a toy demo

This is not a hardcoded, single-dataset toy: the dataset-first layer
(`src/data_engine/`) has real input validation (row/size limits,
dataset-ID allowlisting against path traversal, safe JSON serialization
of NaN/Infinity/NumPy types), consistent error handling with a stable
JSON error envelope and no leaked tracebacks or filesystem paths, genuine
per-dataset isolation on disk, and a test suite that specifically
verifies non-fabrication (every capability reason is checked to be
real and specific) and correct behavior on adversarial/edge-case input
(ambiguous schemas, zero-signal datasets, path-traversal dataset IDs,
empty dataframes). The legacy MMM pipeline it sits alongside was already
built with equivalent production discipline (documented modeling
choices, time-aware train/test splitting, honest reporting of model
selection and limitations — see `docs/methodology.md`). The explicit,
non-silent handling of "this analysis isn't available for this data, and
here's exactly why" is itself a production-grade design choice, not an
afterthought.
